def policy(resource):
    return resource['LoggingPolicy'] is not None
