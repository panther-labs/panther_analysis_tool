def policy(resource):
    return '.' not in resource['Name']
