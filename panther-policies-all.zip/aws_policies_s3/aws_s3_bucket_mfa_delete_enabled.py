def policy(resource):
    return resource['MFADelete'] == 'Enabled'
