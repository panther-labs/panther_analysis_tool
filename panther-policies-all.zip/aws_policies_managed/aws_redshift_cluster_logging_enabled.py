def policy(resource):
    return resource['LoggingStatus']['LoggingEnabled']
