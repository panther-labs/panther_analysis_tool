def policy(resource):
    return resource['Users'] is not None
