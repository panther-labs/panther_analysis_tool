def policy(resource):
    return bool(resource['KmsKeyId'])
