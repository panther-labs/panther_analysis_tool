def policy(resource):
    return resource['GlobalResourcesEnabled']
