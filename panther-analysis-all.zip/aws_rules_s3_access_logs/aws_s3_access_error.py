def rule(event):
    return 'errorCode' in event
